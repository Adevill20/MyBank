'use strict';

app.models.map = (function() {
    return {};
})();